using dpu.Entities;
using dpu.Models;
using dpu.Services;
using Microsoft.AspNetCore.Mvc;

namespace dpu.Controllers;

[ApiController]
[Route("[controller]")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductsController(IProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    public IActionResult GetProducts()
    {
        var response = _productService.GetProducts();
        return Ok(response);
    }

    [HttpGet("{id}")]
    public IActionResult GetProduct(int id)
    {
        var response = _productService.GetProduct(id);
        return Ok(response);
    }

    [HttpGet("ProductById/{id}")]
    public IActionResult GetProductById(int id)
    {
        var response = _productService.GetProductById(id);
        return Ok(response);
    }

    [HttpGet("ProductByIdVersion2/{id}")]
    public IActionResult GetProductByIdVersion2(int id)
    {
        var response = _productService.GetProductByIdVersion2(id);
        return Ok(response);
    }

    [HttpPost]
    public IActionResult CreateProduct(ProductRequest product)
    {
        Product _product = new Product();
        _product.Title = product.Title;
        _product.IsActive = product.IsActive;
        _product.CategoryId = product.CategoryId;

        var response = _productService.CreateProduct(_product);
        return Ok(response);
    }

    [HttpPut]
    public IActionResult EditProduct(ProductEdit product)
    {
        Product _product = new Product();
        _product.Title = product.Title;
        _product.IsActive = product.IsActive;
        _product.CategoryId = product.CategoryId;
        _product.Id = product.Id;

        var response = _productService.EditProduct(_product);
        return Ok(response);
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteProduct(int id)
    {
        var response = _productService.DeleteProduct(id);
        return Ok(response);
    }
}
