using dpu.Entities;

namespace dpu.Services;

public interface IProductService
{
    List<Product> GetProducts();
    Product? GetProduct(int id);
    Product? GetProductById(int id);
    Product? GetProductByIdVersion2(int id);
    Product CreateProduct(Product product);
    Product EditProduct(Product product);
    Product DeleteProduct(int id);
}