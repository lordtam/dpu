using dpu.Entities;
using dpu.Repositories;

namespace dpu.Services;

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    public Product? GetProduct(int id)
    {
        return _productRepository.GetProduct(id);
    }

    public List<Product> GetProducts()
    {
        return _productRepository.GetProducts().Where(w => w.IsActive).ToList();
    }

    public Product? GetProductById(int id)
    {
        return _productRepository.GetProductById(id);
    }

    public Product? GetProductByIdVersion2(int id)
    {
        return _productRepository.GetProductByIdVersion2(id);
    }

    public Product CreateProduct(Product product)
    {
        return _productRepository.CreateProduct(product);
    }

    public Product EditProduct(Product product)
    {
        return _productRepository.EditProduct(product);
    }

    public Product DeleteProduct(int id)
    {
        return _productRepository.DeleteProduct(id);
    }
}