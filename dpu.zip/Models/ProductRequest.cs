namespace dpu.Models;

public class ProductRequest
{
    public string Title { get; set; }
    public bool IsActive { get; set; }
    public int CategoryId { get; set; }
}

public class ProductEdit : ProductRequest
{
    public int Id { get; set; }
}