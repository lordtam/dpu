﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace dpu.Entities
{
    [Table("Product")]
    public partial class Product
    {
        [Key]
        public int Id { get; set; }
        [StringLength(100)]
        public string Title { get; set; } = null!;
        public bool IsActive { get; set; }
        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        [InverseProperty("Products")]
        public virtual Category Category { get; set; } = null!;
    }
}
